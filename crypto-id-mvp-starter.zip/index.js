
import React, { useState } from "react";
import QRCode from "qrcode.react";
import "./styles/globals.css";

export default function App() {
  const [wallets] = useState([
    { chain: "Ethereum", address: "0x1234...abcd" },
    { chain: "Solana", address: "So1anaAddre5sHere" },
    { chain: "Bitcoin", address: "1BitcoinAddressXYZ" },
  ]);

  return (
    <div className="container">
      <div className="profile">
        <img src="https://placehold.co/100x100" alt="Profile" className="avatar" />
        <h1 className="username">@julia</h1>
        <p className="bio">Street Artist | Accepting crypto donations 💸</p>
      </div>

      <div className="wallets">
        {wallets.map((w) => (
          <div key={w.chain} className="wallet-card">
            <div className="wallet-info">
              <div>
                <p className="chain">{w.chain}</p>
                <p className="address">{w.address}</p>
              </div>
              <div>
                <QRCode value={w.address} size={64} />
              </div>
            </div>
            <button className="copy-btn" onClick={() => navigator.clipboard.writeText(w.address)}>
              Copy address
            </button>
          </div>
        ))}
      </div>

      <p className="footer-note">
        Always double-check the URL. This is my only crypto profile.
      </p>
    </div>
  );
}
